package com.greenlink.greenlink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenLinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
